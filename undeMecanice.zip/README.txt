Corpurile se misca in felul urmator:
- din W,A,S,D, fara a apasa butoane de mouse: se misca sursa de picaturi;
- din SPACE, fara a apasa butoane de mouse: se genereaza o picatura;
- din Y,G,H,J,T,U, fara a apasa butoane de mouse: se misca sursa de lumina;
- din W,A,S,D,Q,E, cu click-dreapta: se misca camera FPS.
De asemenea cu click-dreapta si miscarea mouse-ului se roteste camera FPS.
Efectul de slow motion este accentuat de apasarea tastei O.
Efectul de fast motion este accentuat de apasarea tastei P.
Un varf este reprezentat de un sinus, iar normalele sunt calculate pe baza derivatelor, in rest iluminarea este bazata pe ce am facut in laboratoarele 7 si 8.
Am facut bonusul "Posibilitatea de a lansa mai multe picaturi in acelasi timp pe pozitii diferite".
